#!/usr/bin/env
from write import *
from ICMP import *
from Radio import *



packets = packets_write();
packets.extractPackets();
packets.arrangePackets();
packets.writePackets();

radio = Radio();
radio.uplink();
radio.downlink();

icmp = MyICMP();
icmp.callPing();
if icmp.getError():
	print("Error in IMCP paramter");
else:
	print("Success Rate:", str(icmp.getSuccessRate()));
	print("Round Trip Time:", str(icmp.getroundTripTime()));


